const s=globalThis.__sveltekit_1jajob8?.base??"/yadr",a=globalThis.__sveltekit_1jajob8?.assets??s??"";export{a,s as b};
