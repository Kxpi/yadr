const s=globalThis.__sveltekit_qvba7y?.base??"/yadr",a=globalThis.__sveltekit_qvba7y?.assets??s??"";export{a,s as b};
